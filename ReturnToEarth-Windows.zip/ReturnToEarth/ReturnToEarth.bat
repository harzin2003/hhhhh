@echo off
setlocal enabledelayedexpansion
title Return to Earth
cd /d "%~dp0game"
if not exist "three.min.js" (
  echo [First run] Downloading the 3D library, please wait...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js' -OutFile 'three.min.js' } catch { }"
)
set "P=%CD:\=/%"
set "URL=file:///!P: =%%20!/index.html"
set FLAGS=--app=!URL! --start-fullscreen --no-first-run --no-default-browser-check --autoplay-policy=no-user-gesture-required --user-data-dir="%LOCALAPPDATA%\ReturnToEarth"
for %%B in ("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe") do (
  if exist %%B (
    start "" %%B !FLAGS!
    exit /b 0
  )
)
echo Edge or Chrome was not found. Opening in your default browser...
start "" "!URL!"
