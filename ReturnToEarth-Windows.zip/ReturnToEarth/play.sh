#!/bin/sh
# Linux / macOS launcher
DIR="$(cd "$(dirname "$0")/game" && pwd)"
[ -f "$DIR/three.min.js" ] || curl -sL -o "$DIR/three.min.js" https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
URL="file://$(printf '%s' "$DIR" | sed 's/ /%20/g')/index.html"
FLAGS="--app=$URL --start-fullscreen --autoplay-policy=no-user-gesture-required --user-data-dir=$HOME/.returntoearth"
for B in google-chrome chromium chromium-browser microsoft-edge; do command -v $B >/dev/null 2>&1 && exec $B $FLAGS; done
[ -d "/Applications/Google Chrome.app" ] && exec open -na "Google Chrome" --args $FLAGS
[ -d "/Applications/Microsoft Edge.app" ] && exec open -na "Microsoft Edge" --args $FLAGS
echo "Chrome/Edge not found"; exit 1
