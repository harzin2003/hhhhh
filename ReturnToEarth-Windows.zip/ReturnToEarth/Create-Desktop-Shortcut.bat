@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Return to Earth.lnk');$s.TargetPath='%~dp0ReturnToEarth.bat';$s.WorkingDirectory='%~dp0';$s.IconLocation='%~dp0game\icon.ico';$s.WindowStyle=7;$s.Save()"
echo.
echo Shortcut "Return to Earth" was created on your Desktop.
pause
