#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "Install Node.js first: https://nodejs.org"; exit 1; }
export DEV_LOGIN=1
( sleep 2; (google-chrome http://localhost:3000 || chromium http://localhost:3000 || open -a "Google Chrome" http://localhost:3000 || xdg-open http://localhost:3000) >/dev/null 2>&1 ) &
node server.js
