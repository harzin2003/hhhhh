﻿العودة إلى الأرض — نسخة السيرفر (تسجيل دخول بقوقل + حفظ النقاط + لوحة المتصدرين)
============================================================================

ماذا يفعل؟
 - يعرض اللعبة على الإنترنت (أو على جهازك) من عنوان ويب واحد.
 - تسجيل الدخول بحساب قوقل، واسم لاعب تختاره أنت (يُحفظ ويمكن تغييره).
 - يحفظ أفضل نتيجة وأعلى مرحلة وصلتَ إليها لكل لاعب.
 - عند انتهاء اللعبة أو خسارة المحاولات تظهر لوحة المتصدرين: 🥇🥈🥉 لأعلى ثلاثة، وتظهر مرتبتك.
 - لا يحتاج أي مكتبات (npm) — فقط Node.js الإصدار 18 أو أحدث.

0) أسرع طريقة للتجربة في Chrome على جهازك (بدون GitHub)
   - ثبّت Node.js (LTS) من nodejs.org ثم فكّ ضغط هذا المجلد.
   - ويندوز: انقر مرتين على  Start-Local.bat  (ماك/لينكس: ./start-local.sh) فيعمل السيرفر ويفتح Chrome على  http://localhost:3000
   - اترك نافذة السيرفر مفتوحة أثناء اللعب، وأغلقها لإيقاف السيرفر.
   - يظهر في لوحة 🏆 زر قوقل + «دخول تجريبي» (اسم فقط) لتجرّب الحفظ فوراً.
   - لزر قوقل: أضف  http://localhost:3000  إلى Authorized JavaScript origins في Google Cloud (وقد يستغرق التفعيل دقائق).

1) تشغيل تجريبي على جهازك (بدون قوقل)
   node server.js
   ثم افتح  http://localhost:3000  — سيظهر «دخول تجريبي» (اسم فقط) لتجرّب الحفظ واللوحة.
   اضغط 🏆 في أعلى الشاشة (من الشاشة الأولى أو بين المراحل) لفتح اللوحة والحساب.

2) تسجيل الدخول بقوقل — معرّف التطبيق مضبوط مسبقاً في server.js
   (Client ID: 928530343211-0sre05nbqjrh7pksdo1fh0ijrt2c7mie.apps.googleusercontent.com)
   المطلوب منك فقط: إضافة عناوين موقعك إلى «Authorized JavaScript origins» في قوقل:
      http://localhost:3000   و   https://harzinhk40.onrender.com
   وإلا يظهر خطأ origin_mismatch. وإن أردتَ تغيير المعرّف لاحقاً فاستعمل المتغير GOOGLE_CLIENT_ID.

   (للمرجع) كيف يُنشأ المعرّف:
   أ) افتح  https://console.cloud.google.com  وأنشئ مشروعاً.
   ب) APIs & Services ▸ OAuth consent screen: اختر External وأكمل الاسم والبريد (أثناء التجربة أضف بريدك في Test users).
   ج) APIs & Services ▸ Credentials ▸ Create credentials ▸ OAuth client ID ▸ نوع التطبيق: Web application.
   د) في Authorized JavaScript origins أضف:  http://localhost:3000   وعنوان موقعك بعد النشر مثل  https://اسم-موقعك.onrender.com
      (لا تضع مسارات؛ العنوان فقط).
   هـ) انسخ «Client ID» وشغّل السيرفر به:
        ويندوز (PowerShell):   $env:GOOGLE_CLIENT_ID="ضع-المعرّف-هنا"; node server.js
        لينكس / ماك:          GOOGLE_CLIENT_ID=ضع-المعرّف-هنا node server.js
   عندها يظهر زر «Sign in with Google» في اللوحة، ويتوقف الدخول التجريبي تلقائياً.
   ملاحظة: يعمل زر قوقل فقط حين تفتح اللعبة من عنوان السيرفر (http/https) وليس من ملف على الجهاز.

3) النشر على الإنترنت (خيارات مجانية/رخيصة)
   - Render.com أو Railway.app أو Fly.io: ارفع هذا المجلد (أو من GitHub)، أمر التشغيل  node server.js ،
     وأضف متغير البيئة  GOOGLE_CLIENT_ID  (واختيارياً SESSION_SECRET).
   - مهم: النتائج تُحفظ في ملف داخل مجلد data. بعض الاستضافات المجانية تمسح الملفات عند إعادة التشغيل،
     فاربط «Persistent Disk/Volume» واجعل المتغير DATA_DIR يشير إليه (مثل /data). يوجد Dockerfile جاهز.
   - بعد النشر أضف عنوان موقعك إلى Authorized JavaScript origins في قوقل (الخطوة 2-د).

4) مع تطبيق ويندوز
   ضع عنوان السيرفر (سطر واحد، مثل https://اسم-موقعك.onrender.com) في ملف نصي اسمه server.txt بجانب ReturnToEarth.bat
   فتفتح اللعبة من السيرفر وتعمل لوحة المتصدرين وتسجيل قوقل داخل نافذة التطبيق.


5) الرابط: harzinhk40
   - رابط Claude المنشور لا يمكن تغييره (تحدده المنصة). أما سيرفرك فتختار اسمه أنت.
   - على Render يوجد ملف render.yaml جاهز باسم الخدمة harzinhk40، فيصبح الرابط:  https://harzinhk40.onrender.com
     (إن كان الاسم محجوزاً سيطلب منك اسماً آخر، مثل harzinhk40-game).
     الخطوات: ارفع المجلد على GitHub ثم في Render اختر New ▸ Blueprint ▸ اختر المستودع.
   - بعد ظهور الرابط، أضفه في قوقل: Credentials ▸ Authorized JavaScript origins ▸  https://harzinhk40.onrender.com
   - الاسم بلا امتداد (http://HarzinHk40) لا يعمل على الإنترنت، ولا يقبله قوقل لتسجيل الدخول. للحصول على رابط
     بلا «onrender» اشترِ نطاقاً (مثل harzinhk40.com) واربطه بالاستضافة، ثم أضفه في قوقل أيضاً.

الأمان والغش
 - السيرفر يتحقق من هوية قوقل بنفسه، ويمنع تكرار الأسماء، ويحدّ من معدل إرسال النتائج،
   ويرفض النتائج الأكبر من حد معقول لكل مرحلة. لكن اللعبة تعمل داخل متصفح اللاعب، فمن يملك مهارة تقنية
   قد يرسل نتيجة معقولة الشكل مزيّفة. المنع التام يتطلب تشغيل منطق اللعبة على السيرفر نفسه.

واجهة API (للمطوّرين)
 GET /api/config • POST /api/login {credential} • POST /api/dev-login {name} • GET /api/me
 POST /api/profile {name} • POST /api/score {score,level,final} • GET /api/leaderboard?limit=10
 (الجلسة: Authorization: Bearer <token>)

تطوير HarzinHk
