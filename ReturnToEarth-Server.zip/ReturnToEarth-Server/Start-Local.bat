@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Download it from https://nodejs.org  ^(LTS version^), install it, then run this file again.
  pause
  exit /b 1
)
set DEV_LOGIN=1
echo Starting the game server...
start "Return to Earth server (close this window to stop)" node server.js
timeout /t 2 >nul
start "" chrome "http://localhost:3000" || start "" "http://localhost:3000"
